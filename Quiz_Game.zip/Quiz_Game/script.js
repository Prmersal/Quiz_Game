var one = document.getElementById("one");
var result = document.getElementById("result");
var score = document.getElementById("score");
var random = Math.floor(Math.random() * 10) + 1;
var totalscores = 10;

function check() {
    var enternumber = parseInt(one.value, 10);

    if (isNaN(enternumber)) {
        result.textContent = "Please enter a number!";
        return; // Exit the function if no number is entered
    }

    if (random === enternumber) {
        console.log("Right");
        result.textContent = "Right😎";
        alert("Congratulations! You Won");
    } else {
        totalscores = Math.max(0, totalscores - 1);
        score.textContent = "Score: " + totalscores;
        result.textContent = "Wrong!😕";
    }
}